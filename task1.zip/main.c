/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void create_file(const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Error creating file");
        return;
    }
    printf("File '%s' created successfully.\n", filename);
    fclose(file);
}

void write_to_file(const char *filename, const char *data) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Error opening file for writing");
        return;
    }
    fprintf(file, "%s", data);
    printf("Data written to file '%s'.\n", filename);
    fclose(file);
}

void append_to_file(const char *filename, const char *data) {
    FILE *file = fopen(filename, "a");
    if (file == NULL) {
        perror("Error opening file for appending");
        return;
    }
    fprintf(file, "%s", data);
    printf("Data appended to file '%s'.\n", filename);
    fclose(file);
}

void read_file(const char *filename) {
    char buffer[256];
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file for reading");
        return;
    }

    printf("Contents of the file '%s':\n", filename);
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        printf("%s", buffer);
    }

    fclose(file);
}

int main() {
    const char *filename = "example.txt";
    int choice;
    char data[256];

    while (1) {
        printf("\nFile Operations:\n");
        printf("1. Create File\n");
        printf("2. Write to File\n");
        printf("3. Append to File\n");
        printf("4. Read File\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // to consume the newline character

        switch (choice) {
        case 1:
            create_file(filename);
            break;
        case 2:
            printf("Enter data to write to the file: ");
            fgets(data, sizeof(data), stdin);
            data[strcspn(data, "\n")] = 0; // Remove newline
            write_to_file(filename, data);
            break;
        case 3:
            printf("Enter data to append to the file: ");
            fgets(data, sizeof(data), stdin);
            data[strcspn(data, "\n")] = 0; // Remove newline
            append_to_file(filename, data);
            break;
        case 4:
            read_file(filename);
            break;
        case 5:
            printf("Exiting program.\n");
            exit(0);
        default:
            printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}
